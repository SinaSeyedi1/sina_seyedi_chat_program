﻿



// The "using System" directive allows access for classes and the system library.
using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;
using Windows_Forms_Chat;

// The "namespace" container provides seperation and avoids confliction between class anme. 
namespace Windows_Forms_Chat

{// The "public class" access modifier allows access for all members.
    public class TCPChatServer : TCPChatBase
    {
        // Offers a socket for the server.
        public Socket serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        // This segment allows connection for clients and a list to maintain the client sockets. 
        public List<ClientSocket> clientSockets = new List<ClientSocket>();

        public static TCPChatServer createInstance(int port, TextBox chatTextBox)
        {
            TCPChatServer tcp = null;
            // This will assess if a port within range is appropritae, and if a chat box is issued.
            if (port > 0 && port < 65535 && chatTextBox != null)
            {
                tcp = new TCPChatServer();
                tcp.port = port;
                tcp.chatTextBox = chatTextBox;

            }

            // This segment will return empty values if user does not enter sufficient details.
            return tcp;
        }
        // Deploys a listener for connections.
        public void SetupServer()
        {
            chatTextBox.Text += "Setting up server...\n";
            serverSocket.Bind(new IPEndPoint(IPAddress.Any, port));
            serverSocket.Listen(0);
            // Iniates the accepting of connections.
            serverSocket.BeginAccept(AcceptCallback, this);
            chatTextBox.Text += "Server setup complete\n";
        }


        // The "public void CloseAllSockets" method closes all of the client and server sockets.
        public void CloseAllSockets()
        {
            foreach (ClientSocket clientSocket in clientSockets)
            {
                clientSocket.socket.Shutdown(SocketShutdown.Both);
                clientSocket.socket.Close();
            }
            clientSockets.Clear();
            serverSocket.Close();
        }

        // The "AcceptCallBack" method is notfies once a connection is received.
        public void AcceptCallback(IAsyncResult AR)
        {
            Socket joiningSocket;

            try
            {
                joiningSocket = serverSocket.EndAccept(AR);
            }
            catch (ObjectDisposedException) // I cannot seem to avoid this (on exit when properly closing sockets)
            {
                return;
            }

            // A new socket is made for the new client.
            ClientSocket newClientSocket = new ClientSocket();
            newClientSocket.socket = joiningSocket;

            clientSockets.Add(newClientSocket);
            // A thread is created to listen and be aware for the newly joining socket.
            joiningSocket.BeginReceive(newClientSocket.buffer, 0, ClientSocket.BUFFER_SIZE, SocketFlags.None, ReceiveCallback, newClientSocket);
            AddToChat("Client connected, waiting for request...");

            // This allows more client to join.
            serverSocket.BeginAccept(AcceptCallback, null);
        }
        // Notifies the server whenever data is accepted from the client's side.
        public void ReceiveCallback(IAsyncResult AR)
        {
            ClientSocket currentClientSocket = (ClientSocket)AR.AsyncState;

            int received;

            try
            {
                received = currentClientSocket.socket.EndReceive(AR);
            }
            catch (SocketException)
            {
                AddToChat("Client forcefully disconnected");
                // Do not shutdown since the socket may be disposed and might be already disconnected.
                currentClientSocket.socket.Close();
                clientSockets.Remove(currentClientSocket);
                return;
            }

            byte[] recBuf = new byte[received];
            Array.Copy(currentClientSocket.buffer, recBuf, received);
            string text = Encoding.ASCII.GetString(recBuf);

            AddToChat(text);

            string[] message = text.Split(' ');
            switch (message[0].ToLower())
            {
                // The "!username" command allows a client to set their desired username.
                case "!username":
                    if (message.Length > 1)
                    {
                        currentClientSocket.username = message[1];
                        AddToChat("Client username has been set to: " + message[1]);

                    }
                    // The "!user" command allows a client to change their current username.
                    break;
                case "!user":
                    if (message.Length > 1)
                    {
                        currentClientSocket.username = message[1];
                        AddToChat("Client username has been successfully changed to: " + message[1]);
                    }

                    // The "!commands" command lists the below texts.
                    break;
                case "!commands":
                    byte[] data = Encoding.ASCII.GetBytes("Commands are !commands !about !who !whisper !exit");
                    currentClientSocket.socket.Send(data);
                    AddToChat("Commands sent to client");
                    break;

                // The "!who" command sends connected users to the client.
                case "!who":
                    StringBuilder userList = new StringBuilder("Connected users");
                    foreach (ClientSocket client in clientSockets)
                    {
                        userList.Append(" " + client.username);

                    }
                    byte[] whoData = Encoding.ASCII.GetBytes(userList.ToString());
                    currentClientSocket.socket.Send(whoData);
                    AddToChat("Connected users have been sent to the client");
                    break;

                // The "!about" command sends the server details to the client.
                case "!about":
                    string aboutMessage = "This Server was created by Sina Seyedi in the year of 2024, with the purpose of completing NDS203 Assessment 2.";
                    byte[] aboutdata = Encoding.ASCII.GetBytes(aboutMessage);
                    currentClientSocket.socket.Send(aboutdata);
                    AddToChat("Server information has been sent to the client");
                    break;

                // The "!whisper" command privately sends a message to the selected user.
                case "!whisper":
                    if (message.Length > 1)
                    {
                        string targetUsername = message[1];
                        string whisperMessage = string.Join(" ", message, 2, message.Length - 2);
                        bool foundRecipient = false;
                        foreach (ClientSocket client in clientSockets)
                        {
                            if (client.username.Equals(targetUsername, StringComparison.OrdinalIgnoreCase))
                            {
                                byte[] whisperData = Encoding.ASCII.GetBytes("[Whisper] " + currentClientSocket.username + ": " + whisperMessage);
                                client.socket.Send(whisperData);
                                foundRecipient = true;
                                break;
                            }
                        }
                        if (foundRecipient)
                        {
                            byte[] errorData = Encoding.ASCII.GetBytes("The username '" + targetUsername + "' could not be found.");
                            currentClientSocket.socket.Send(errorData);

                        }
                    }
                    else
                    {
                        byte[] errorData = Encoding.ASCII.GetBytes("Usage: !whisper [username]");
                        currentClientSocket.socket.Send(errorData);

                    }
                    break;
                // The program will disconnect user from the server.
                case "!exit":
                    currentClientSocket.socket.Shutdown(SocketShutdown.Both);
                    currentClientSocket.socket.Close();
                    clientSockets.Remove(currentClientSocket);
                    AddToChat("Client disconnected");
                    return;

                // The "!mod" command can be used to promote or demote a client to moderator.
                case "!mod":
                    if (message.Length > 1)
                    {
                        string targetUsername = message[1];
                        ClientSocket targetClient = clientSockets.Find(c => c.username.Equals(targetUsername, StringComparison.OrdinalIgnoreCase));
                        if (targetClient != null)
                        {
                            if (targetClient.isModerator)
                            {
                                targetClient.isModerator = false;
                                // By using !mod [username] the second time, the elected client eill be dmeoted back from moderator.
                                AddToChat(targetUsername + " has been demoted back to normal client.\n");
                            }
                            else
                            {
                                targetClient.isModerator = true;
                                // By using !mod [username] the client will be promoted to moderator, and will have auhtority to kick out other clients.
                                AddToChat(targetUsername + " has been promoted from normal client to moderator.\n");
                            }
                        }
                        else
                        {
                            // If an unassigned username is used, the below message is ouputted.
                            AddToChat("The username '" + targetUsername + "' does not exist, please enter a valid username\n");
                        }
                    
                    }
                    break;

                // The "!kick" command is implemented by the promoted modertaor to kick out the selected client using !kick along with the username.
                case "!kick":
                    if (message.Length > 1)
                    {
                        string targetUsername = message[1];
                        ClientSocket targetClient = clientSockets.Find(c => c.username.Equals(targetUsername, StringComparison.OrdinalIgnoreCase));
                        if (targetClient != null)
                        {
                            byte[] kickData = Encoding.ASCII.GetBytes("The moderator has kicked you from the server.");
                            targetClient.socket.Send(kickData);
                            targetClient.socket.Shutdown(SocketShutdown.Both);
                            targetClient.socket.Close();
                            clientSockets.Remove(targetClient);
                            // When a client is kicked, the server will output the below message.
                            AddToChat(targetUsername + " has been kicked out from server by the moderator.\n");
                        }
                    }
                    break;
            }
            currentClientSocket.socket.BeginReceive(currentClientSocket.buffer, 0, ClientSocket.BUFFER_SIZE, SocketFlags.None, ReceiveCallback, currentClientSocket);
        }

        public void SendToAll(string str, ClientSocket from)
        {
            foreach (ClientSocket c in clientSockets)
            {
                if (from == null || !from.socket.Equals(c))
                {
                    byte[] data = Encoding.ASCII.GetBytes(str);
                    c.socket.Send(data);
                }
            }
        }
    }
}