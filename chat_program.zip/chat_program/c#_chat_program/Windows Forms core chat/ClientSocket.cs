﻿using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;

namespace Windows_Forms_Chat
{
    public class ClientSocket
    {
        // The "public string username" field allows for storing the client's designated username.
        public string username;

        // The "public bool isModerator" field decides if a clinet has moderator authority.
        public bool isModerator;

        // The "Public Socket socket" field maintains server connection and is responsible for network communication for the client.
        public Socket socket;

        // The number "2048" determines the highest size of buffer that can be processed. 
        public const int BUFFER_SIZE = 2048;
        public byte[] buffer = new byte[BUFFER_SIZE];

        }
    }








